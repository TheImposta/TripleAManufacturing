import { supabase } from './supabase.js';

async function loadOrders() {
  const { data } = await supabase.from('orders').select('*, products(name)');
  document.getElementById('orders').innerHTML =
    data.map(o => `<p>${o.products.name} – Qty ${o.quantity}</p>`).join('');
}

window.addProduct = async () => {
  await supabase.from('products').insert({
    name: name.value,
    size: size.value,
    color: color.value,
    thickness_microns: thickness.value,
    price_per_1000: price.value
  });
  alert('Product added');
};

loadOrders();
