import { supabase } from "./supabase.js";

// Check if user is logged in and update UI
export async function checkUser() {
  const { data: { user } } = await supabase.auth.getUser();
  const authLink = document.getElementById('auth-link');
  
  if (authLink) {
    if (user) {
      authLink.innerText = "Sign Out";
      authLink.href = "#";
      authLink.onclick = async () => {
        await supabase.auth.signOut();
        window.location.reload();
      };
    } else {
      authLink.innerText = "Sign In";
      authLink.href = "auth.html";
    }
  }
  return user;
}

// Handle Login/Signup if on auth page
const signInBtn = document.getElementById('signInBtn');
const signUpBtn = document.getElementById('signUpBtn');

if (signInBtn) {
  signInBtn.onclick = async () => {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) alert(error.message);
    else window.location.href = "products.html";
  };

  signUpBtn.onclick = async () => {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const { error } = await supabase.auth.signUp({ email, password });
    if (error) alert(error.message);
    else alert("Check your email for the confirmation link!");
  };
}