// public/js/config.js
export const CONFIG = {
  SUPABASE_URL: "https://cfslslxrbqmlxhpzkiwt.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_ANON_KEY_HERE",
  STRIPE_PUBLIC_KEY: "pk_test_YOUR_STRIPE_KEY"
};