import { supabase } from "./supabase.js";

const container = document.getElementById("product-list");

async function loadProducts() {
  const { data, error } = await supabase.from("products").select("*");
  
  if (error) {
    console.error(error);
    return;
  }

  container.innerHTML = ""; // Clear loader
  
  data.forEach(p => {
    const card = document.createElement("div");
    card.className = "product-card";
    card.innerHTML = `
      <div>
        <h3>${p.name}</h3>
        <p style="margin: 0;">${p.size} &middot; ${p.color}</p>
        <p style="font-size: 14px; opacity: 0.7;">${p.thickness_microns} microns</p>
      </div>
      
      <div class="price">
        <span>$${p.price_per_1000} / 1k units</span>
        <div style="display: flex; gap: 10px; margin-top: 15px;">
           <input type="number" id="qty-${p.id}" value="1000" step="1000" min="1000">
           <button onclick="window.initiateOrder('${p.id}', '${p.name}', ${p.price_per_1000})">Order</button>
        </div>
      </div>
    `;
    container.appendChild(card);
  });
}

loadProducts();